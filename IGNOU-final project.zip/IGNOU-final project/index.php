<?php
// minibazar
session_start();

include("includes/db.php");
include("includes/header.php");
include("functions/functions.php");
include("includes/main.php");

?>


  <!-- Cover -->
  <main>
    <div class="hero">
      <a href="shop.php" class="btn1">View all products
</a>
    </div>
    <!-- Main -->
    <div class="wrapper">
            <h1>Featured Collection<h1>
            
      </div>



    <div id="content" class="container"><!-- container Starts -->

    <div class="row"><!-- row Starts -->

    <?php

    getPro();

    ?>

    </div><!-- row Ends -->

    </div><!-- container Ends -->
    <!-- FOOTER -->
    <footer class="page-footer">

      <div class="footer-nav">
        <div class="container clearfix">

          <div class="footer-nav__col footer-nav__col--info">
            <div class="logo">
              <a class="logo__link" href="index.php">
                <img class="logo__img" src="images/logo.png" alt="minibazar" width="237" height="19">
              </a>
            </div>
            <br>
            <div class="footer-nav__heading"></div>
            <ul class="footer-nav__list">
              <li class="footer-nav__item">
                <a href="#" class="footer-nav__link">Welcome to mini_Bazar! We founded this business after realizing the lack of localized e-Shops. <br>
                  Now, we're dedicated to localized the e-com by providing Products that are best in Quality & Price.</a>
              </li>
            </ul>
          </div>

          <div class="footer-nav__col footer-nav__col--contacts">
            <div class="footer-nav__heading">Contact details</div>
            <address class="address">
            Head Office: IGNOU, Naraina Vihar,
            <br>
            New Delhi-110028, Delhi, India.
          </address>
            <div class="phone">
              Telephone:
              <a class="phone__number" href="tel:0123456789">+91-0123456789</a>
            </div>
            <div class="email">
              Email:
              <a href="mailto:support@minibazarxyz.com" class="email__addr">support@minibazarxyz.com</a>
            </div>
          </div>

        </div>
      </div>

      <div class="banners">
        <div class="container clearfix">

          <div class="banner-social">
            <a href="#" class="banner-social__link">
            <i class="icon-facebook"></i>
          </a>
            <a href="#" class="banner-social__link">
            <i class="icon-twitter"></i>
          </a>
            <a href="#" class="banner-social__link">
            <i class="icon-instagram"></i>
          </a>
            <a href="#" class="banner-social__link">
            <i class="icon-pinterest-circled"></i>
          </a>
          </div>

        </div>
      </div>

      <div class="page-footer__subline">
        <div class="container clearfix">

          <div class="copyright">
            &copy; <?php echo date("Y");?> Ecommerce Website IGNOU&trade;
          </div>

          <div class="developer">
            Developed by Pranav
          </div>

        </div>
      </div>
    </footer>
</body>

</html>
